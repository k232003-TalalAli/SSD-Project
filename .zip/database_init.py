# seed_firebase.py  — run this once to upload your existing files

from database_helper import (
    update_des_key, update_account, update_chatlogs
)

# ── app_data.txt ──────────────────────────────────────────────────────────────
update_des_key("0123456789abcdef")

update_account("1", {
    "username":    "Talal",
    "password":    "9bc34549d565d9505b287de0cd20ac77be1d3f2c",
    "ip_address":  None,
    "public_key":  "8d00c7ac2f88d18ba62b13a7668d0fe6",
    "private_key": "f659895dfde51e212daf05aca6a0da5a",
})

update_account("2", {
    "username":    "Dani",
    "password":    "9bc34549d565d9505b287de0cd20ac77be1d3f2c",
    "ip_address":  None,
    "public_key":  "fcb87624ea4d55a34b7043f207cd12c0",
    "private_key": "ec61bea92d766c90a9ad133113507b86",
})

# ── chatlogs (load from file) ─────────────────────────────────────────────────
with open("chat_logs.txt", "r", encoding="utf-8") as f:          # adjust filename/mode
    raw = f.read()

# If chatlogs are binary, base64-encode them for safe Firestore storage
import base64
update_chatlogs((raw))

print("Seeded successfully.")